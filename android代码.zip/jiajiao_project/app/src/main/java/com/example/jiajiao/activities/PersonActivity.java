package com.example.jiajiao.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.jiajiao.R;
import com.example.jiajiao.api.ApiService;
import com.example.jiajiao.api.apiInterface.ParentApi;
import com.example.jiajiao.domain.vo.TokenVo;
import com.example.jiajiao.utils.ApiResponse;
import com.example.jiajiao.utils.BaseActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PersonActivity extends BaseActivity {

    private LinearLayout rewordLayout = null;
    private LinearLayout accountLayout = null;
    private LinearLayout logoutLayout = null;
    private TextView textPhone = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.personal_info);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.persona_activity), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        toolbarInit();

        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String parentPhone = prefs.getString("phone", "");
        textPhone = findViewById(R.id.text_phone);
        textPhone.setText(parentPhone);

        layoutInit();

        rewordLayoutClickInit();

        logoutButtonInit();
    }

    private void layoutInit() {
        rewordLayout = findViewById(R.id.item_coupon);
        logoutLayout = findViewById(R.id.item_logout);

    }

    private void logoutButtonInit() {
        logoutLayout.setOnClickListener(v -> {
            // 弹出确认对话框
            new AlertDialog.Builder(PersonActivity.this)
                    .setTitle("退出登录")
                    .setMessage("确定要退出登录吗？")
                    .setPositiveButton("确定", (dialog, which) -> performLogout()) // 点击确定后执行登出
                    .setNegativeButton("取消", null)
                    .show();
        });
    }

    private void performLogout() {
        // 获取本地 存储信息
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String accessToken = prefs.getString("access_token", null);
        String phone = prefs.getString("phone", null);
        String refreshToken = prefs.getString("refresh_token", null);

        if (phone == null) {
            navigateToLogin();
            return;
        }

        // 创建 API 实例
        ParentApi api = ApiService.getParentApi(PersonActivity.this);

        TokenVo tokenVo = new TokenVo(accessToken, refreshToken, phone);

        Call<ApiResponse<Void>> call = api.logout(tokenVo);
        call.enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<ApiResponse<Void>> call, Response<ApiResponse<Void>> response) {
                // 无论成功失败都清除本地信息并跳转登录
                clearLocalUserData();
                navigateToLogin();
            }

            @Override
            public void onFailure(Call<ApiResponse<Void>> call, Throwable t) {
                clearLocalUserData();
                navigateToLogin();
            }
        });
    }


    private void rewordLayoutClickInit() {
        rewordLayout.setOnClickListener(v -> {
            Intent intent = new Intent(PersonActivity.this, RewardActivity.class);
            startActivity(intent);
        });
    }

    private void toolbarInit() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("个人信息");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }


    // 清除本地用户数据
    private void clearLocalUserData() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        prefs.edit().clear().apply();
    }

    // 跳转到登录页面
    private void navigateToLogin() {
        Intent intent = new Intent(PersonActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // 清空返回栈
        startActivity(intent);
        finish();
    }
}
