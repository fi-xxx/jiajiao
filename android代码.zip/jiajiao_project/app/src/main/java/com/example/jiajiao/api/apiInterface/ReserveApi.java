package com.example.jiajiao.api.apiInterface;

import com.example.jiajiao.domain.dto.ReserveDto;
import com.example.jiajiao.domain.vo.ReserveVo;
import com.example.jiajiao.utils.ApiResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * 预约api
 */
public interface ReserveApi {

    /**
     * 预约教师
     *
     * @param reserveDto 预约信息
     * @return 是否预约成功
     */
    @POST("/reserve")
    Call<ApiResponse<Boolean>> bookTeacher(@Body ReserveDto reserveDto);

    /**
     * 获取预约的教师
     *
     * @param parentPhone 家长电话
     * @return 预约的教师列表
     */
    @GET("/reserve")
    Call<ApiResponse<List<ReserveVo>>> getReservedTeacher(
            @Query("parentPhone") String parentPhone
    );

}
