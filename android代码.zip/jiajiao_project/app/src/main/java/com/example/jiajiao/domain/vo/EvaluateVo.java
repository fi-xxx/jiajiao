package com.example.jiajiao.domain.vo;



public class EvaluateVo {
    private String parentPhone;
    private String teacherName;
    private String content;
    private String date;
    private String subject;

    public EvaluateVo(String parentPhone, String teacherName, String content, String date, String subject) {
        this.parentPhone = parentPhone;
        this.teacherName = teacherName;
        this.content = content;
        this.date = date;
        this.subject = subject;
    }

    public String getParentPhone() {
        return parentPhone;
    }

    public void setParentPhone(String parentPhone) {
        this.parentPhone = parentPhone;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherPhone(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
