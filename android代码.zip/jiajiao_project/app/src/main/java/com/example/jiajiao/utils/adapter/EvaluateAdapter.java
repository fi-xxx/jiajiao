package com.example.jiajiao.utils.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jiajiao.R;
import com.example.jiajiao.domain.vo.EvaluateVo;

import java.util.List;

public class EvaluateAdapter extends RecyclerView.Adapter<EvaluateAdapter.EvaluateViewHolder> {

    private List<EvaluateVo> evaluateList;

    public EvaluateAdapter(List<EvaluateVo> evaluateList) {
        this.evaluateList = evaluateList;
    }

    @NonNull
    @Override
    public EvaluateViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_evaluate, parent, false);
        return new EvaluateViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EvaluateViewHolder holder, int position) {
        EvaluateVo evaluate = evaluateList.get(position);
        holder.tvSubjectTeacher.setText(evaluate.getSubject() + " - " + evaluate.getTeacherName());
        holder.tvContent.setText(evaluate.getContent());
        holder.tvPhoneDate.setText("来自 " + evaluate.getParentPhone() + " · " + evaluate.getDate());
    }

    @Override
    public int getItemCount() {
        return evaluateList == null ? 0 : evaluateList.size();
    }

    public static class EvaluateViewHolder extends RecyclerView.ViewHolder {
        TextView tvSubjectTeacher, tvContent, tvPhoneDate;

        public EvaluateViewHolder(@NonNull View itemView) {
            super(itemView);
            tvSubjectTeacher = itemView.findViewById(R.id.tvSubjectTeacher);
            tvContent = itemView.findViewById(R.id.tvContent);
            tvPhoneDate = itemView.findViewById(R.id.tvPhoneDate);
        }
    }

    public void setData(List<EvaluateVo> data) {
        this.evaluateList = data;
        notifyDataSetChanged();
    }
}
