package com.example.jiajiao.domain.dto;

public class TokenDto {

}
