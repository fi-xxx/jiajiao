package com.example.jiajiao.utils;


import static com.example.jiajiao.utils.Constants.BASE_URL;
import static com.example.jiajiao.utils.Constants.TOKEN_HEADER;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.jiajiao.activities.LoginActivity;
import com.example.jiajiao.api.apiInterface.TokenApi;
import com.example.jiajiao.domain.vo.TokenVo;
import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class TokenInterceptor implements Interceptor {
    private final Context context;
    private final Object tokenRefreshLock = new Object();

    // 定义不需要 Token 的请求路径（与后端 Filter  保持一致）
    private final String[] excludedPaths = {
            "/parents/login",
            "/parents/register",
            "/parents/refresh",
            "/error"
    };

    public TokenInterceptor(Context context) {
        this.context = context.getApplicationContext();
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request originalRequest = chain.request();
        String path = originalRequest.url().encodedPath();

        // 1. 检查是否为排除路径（不添加 Token）
        if (isExcludedPath(path)) {
            return chain.proceed(originalRequest);
        }

        // 2. 非排除路径：尝试添加 Token 并处理刷新逻辑
        SharedPreferences prefs = getSecureSharedPreferences();
        String accessToken = prefs.getString("access_token", null);
        Response response = proceedWithToken(chain, originalRequest, accessToken);

        // 3. 处理 Token 过期（401）
        if (response.code() == 401) {
            response.close();
            synchronized (tokenRefreshLock) {
                String newAccessToken = refreshTokenIfNeeded(prefs);
                if (newAccessToken != null) {
                    return proceedWithToken(chain, originalRequest, newAccessToken);
                } else {
                    handleTokenRefreshFailed();
                    return response;
                }
            }
        }
        return response;
    }

    // 检查请求路径是否在排除列表中
    private boolean isExcludedPath(String path) {
        for (String excludedPath : excludedPaths) {
            if (path.startsWith(excludedPath)) {
                return true;
            }
        }
        return false;
    }

    private Response proceedWithToken(Chain chain, Request request, String token) throws IOException {
        Request newRequest = request.newBuilder()
                .header(TOKEN_HEADER, "Bearer " + (token != null ? token : ""))
                .build();
        return chain.proceed(newRequest);
    }

    private String refreshTokenIfNeeded(SharedPreferences prefs) throws IOException {
        String refreshToken = prefs.getString("refresh_token", null);
        String phone = prefs.getString("phone", null);

        if (refreshToken == null) return null;

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        TokenApi api = retrofit.create(TokenApi.class);
        Call<ApiResponse<TokenVo>> call = api.refreshToken(new TokenVo(refreshToken, phone));
        retrofit2.Response<ApiResponse<TokenVo>> apiResponse = call.execute();

        //获取刷新令牌
        if (apiResponse.isSuccessful() && apiResponse.body() != null) {
            //刷新令牌已经过期
            if(apiResponse.body().getMessage().startsWith("刷新令牌无效")){
                return null;
            }
            String newAccessToken = apiResponse.body().getData().getAccessToken();
            String newRefreshToken = apiResponse.body().getData().getRefreshToken();

            prefs.edit()
                    .putString("access_token", newAccessToken)
                    .putString("refresh_token", newRefreshToken)
                    .apply();
            return newAccessToken;
        }
        return null;
    }

    private void handleTokenRefreshFailed() {
        SharedPreferences prefs = getSecureSharedPreferences();
        prefs.edit()
                .remove("access_token")
                .remove("refresh_token")
                .apply();
        Log.d("刷新令牌","刷新令牌无效或已过期");
        Intent intent = new Intent(context, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
    }

    private SharedPreferences getSecureSharedPreferences() {
        return context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE);
    }
}