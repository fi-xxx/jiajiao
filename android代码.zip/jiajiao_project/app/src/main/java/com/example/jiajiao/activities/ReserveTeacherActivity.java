package com.example.jiajiao.activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jiajiao.R;
import com.example.jiajiao.adapter.TeacherBookingAdapter;
import com.example.jiajiao.api.ApiService;
import com.example.jiajiao.api.apiInterface.ReserveApi;
import com.example.jiajiao.domain.vo.ReserveVo;
import com.example.jiajiao.utils.ApiResponse;
import com.example.jiajiao.utils.BaseActivity;


import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReserveTeacherActivity extends BaseActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.message_order_teacher);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.message_order_teacher_layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        toolbarInit();

        getReversedTeacher();

    }


    private void toolbarInit() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("教师预约情况");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void getReversedTeacher() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String phone = prefs.getString("phone","");

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<ReserveVo> bookings = new ArrayList<>();
        TeacherBookingAdapter adapter = new TeacherBookingAdapter(this, bookings);

        ReserveApi api = ApiService.getReserveApi(ReserveTeacherActivity.this);
        Call<ApiResponse<List<ReserveVo>>> call = api.getReservedTeacher(phone);
        call.enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<ApiResponse<List<ReserveVo>>> call, Response<ApiResponse<List<ReserveVo>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<ReserveVo> data = response.body().getData();
                    if (data != null) {
                        bookings.clear();
                        bookings.addAll(data);
                        adapter.notifyDataSetChanged();
                    }
                } else {
                    Log.e("获取预约列表","获取预约信息失败");
                    Toast.makeText(ReserveTeacherActivity.this, "获取预约信息失败", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<ReserveVo>>> call, Throwable t) {
                Toast.makeText(ReserveTeacherActivity.this, "网络请求失败: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("API_ERROR", "onFailure: ", t);
            }
        });

        recyclerView.setAdapter(adapter);
    }
}
