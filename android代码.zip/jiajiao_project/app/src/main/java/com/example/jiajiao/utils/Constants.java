package com.example.jiajiao.utils;

public class Constants {
    public static final String BASE_URL = "http://10.0.2.2:8080";
    public static final String TOKEN_HEADER = "Authorization";
    public static final int TIMEOUT_SECONDS = 30;
    public static final String DEFAULT_AVATAR = "person.png";






}
