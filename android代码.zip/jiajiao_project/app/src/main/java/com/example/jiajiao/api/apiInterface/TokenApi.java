package com.example.jiajiao.api.apiInterface;

import com.example.jiajiao.domain.vo.TokenVo;
import com.example.jiajiao.utils.ApiResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface TokenApi {

    @POST("/parents/refresh")
    Call<ApiResponse<TokenVo>> refreshToken(@Body TokenVo tokenVo);
}
