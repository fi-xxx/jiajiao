package com.example.jiajiao.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.example.jiajiao.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class TimeService extends Service {

    private static Timer timer = null;
    private NotificationManager manager;
    private NotificationCompat.Builder builder;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void cleanAllNotification() {
        manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.cancelAll();
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 1. 创建通知渠道
        String channelId = "channel";
        String channelName = "Notification Channel";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT);
            manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }

        // 2. 构建通知
        builder = new NotificationCompat.Builder(this, channelId)
                .setContentTitle("Time Service Running")
                .setContentText("Service is active and sending notifications.")
                .setSmallIcon(R.drawable.teacher1)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        Notification notification = builder.build();

        // 3. 启动前台服务
        startForeground(1, notification);

        // 4. 启动定时推送逻辑
        long period = 60 * 1000;
        if (timer == null) {
            timer = new Timer();
        }
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Date date = new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                // 添加日志输出
                Log.d("TimeService", "TimerTask triggered at " + formatter.format(date));

                NotificationCompat.Builder notifyBuilder = new NotificationCompat.Builder(TimeService.this, channelId)
                        .setContentTitle("Time Update")
                        .setContentText("Current time: " + formatter.format(date))
                        .setSmallIcon(R.drawable.teacher1)
                        .setAutoCancel(true)
                        .setDefaults(Notification.DEFAULT_ALL)
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                manager.notify(2, notifyBuilder.build());
            }
        }, 0, period);

        return START_STICKY;  // 确保服务在系统杀死后能重新启动
    }

}
