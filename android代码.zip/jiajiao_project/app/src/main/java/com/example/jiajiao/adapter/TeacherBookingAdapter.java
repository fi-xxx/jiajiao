package com.example.jiajiao.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jiajiao.R;
import com.example.jiajiao.domain.vo.ReserveVo;

import java.util.List;

public class TeacherBookingAdapter extends RecyclerView.Adapter<TeacherBookingAdapter.ViewHolder> {

    private Context context;
    private List<ReserveVo> bookingList;

    public TeacherBookingAdapter(Context context, List<ReserveVo> bookingList) {
        this.context = context;
        this.bookingList = bookingList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_teacher_booking, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ReserveVo booking = bookingList.get(position);
        holder.nameText.setText(booking.getTeacherName());
        holder.subjectText.setText(booking.getSubject());
    }

    @Override
    public int getItemCount() {
        return bookingList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameText, subjectText;

        public ViewHolder(View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.teacher_name);
            subjectText = itemView.findViewById(R.id.teacher_subject);
        }
    }
}

