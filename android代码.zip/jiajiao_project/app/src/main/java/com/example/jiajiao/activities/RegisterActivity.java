package com.example.jiajiao.activities;

import static com.example.jiajiao.api.ApiService.getParentApi;
import static com.example.jiajiao.utils.Constants.BASE_URL;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jiajiao.R;
import com.example.jiajiao.api.apiInterface.ParentApi;
import com.example.jiajiao.domain.dto.ParentDto;
import com.example.jiajiao.utils.ApiResponse;
import com.example.jiajiao.utils.BaseActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RegisterActivity extends BaseActivity {

    private EditText etPhone, etPassword, etConfirmPassword;
    private Button btnRegister , btLoginRedirect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        // 获取视图元素
        etPhone = findViewById(R.id.register_phone);
        etPassword = findViewById(R.id.register_password);
        etConfirmPassword = findViewById(R.id.register_confirm_password);
        btnRegister = findViewById(R.id.register);
        btLoginRedirect=  findViewById(R.id.login_redirect);

        btnRegister.setEnabled(false);
        btnRegister.setAlpha(0.5f); // 初始为灰色

        etPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String phoneInput = s.toString();
                // 如果手机号是11位数字，启用按钮；否则禁用
                btnRegister.setEnabled(phoneInput.matches("^\\d{11}$"));
                btnRegister.setAlpha(1.0f);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL) // 替换成你的后端IP和端口
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ParentApi api = retrofit.create(ParentApi.class);
        // 注册按钮点击事件
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = etPhone.getText().toString();
                String password = etPassword.getText().toString();
                String confirmPassword = etConfirmPassword.getText().toString();

                // 校验输入
                if (phone.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "所有字段不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    Toast.makeText(RegisterActivity.this, "密码和确认密码不一致", Toast.LENGTH_SHORT).show();
                    return;
                }

                // 创建 DTO 对象
                ParentDto parentDto = new ParentDto(phone, password);

                //获取Api接口实例
                ParentApi api=getParentApi(RegisterActivity.this);

                // 发起注册请求
                api.register(parentDto).enqueue(new Callback<ApiResponse<Boolean>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<Boolean>> call, Response<ApiResponse<Boolean>> response) {
                        if (response.isSuccessful()) {
                            ApiResponse<Boolean> apiResponse = response.body();
                            if (apiResponse != null && apiResponse.getCode() == 200 && Boolean.TRUE.equals(apiResponse.getData())) {
                                Toast.makeText(RegisterActivity.this, "注册成功，请登录", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                                startActivity(intent);
                                finish(); // 返回登录页面
                            } else {
                                Toast.makeText(RegisterActivity.this, apiResponse != null ? apiResponse.getMessage() : "注册失败", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(RegisterActivity.this, "请求失败", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<Boolean>> call, Throwable t) {
                        Toast.makeText(RegisterActivity.this, "网络异常：" + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        btLoginRedirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

}
