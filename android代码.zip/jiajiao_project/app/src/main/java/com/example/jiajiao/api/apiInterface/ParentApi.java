package com.example.jiajiao.api.apiInterface;

import com.example.jiajiao.domain.dto.ParentDto;
import com.example.jiajiao.domain.vo.ParentVo;
import com.example.jiajiao.domain.vo.TokenVo;
import com.example.jiajiao.utils.ApiResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ParentApi {
    @POST("/parents/login")
    Call<ApiResponse<ParentVo>> login(@Body ParentDto parentDto);

    @POST("/parents/register")
    Call<ApiResponse<Boolean>> register(@Body ParentDto parentDto);


    @POST("/parents/logout")
    Call<ApiResponse<Void>> logout(@Body TokenVo tokenVo);
}
