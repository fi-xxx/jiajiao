package com.example.jiajiao.activities;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jiajiao.R;
import com.example.jiajiao.api.ApiService;
import com.example.jiajiao.api.apiInterface.RewardApi;
import com.example.jiajiao.domain.vo.RewardVo;
import com.example.jiajiao.utils.ApiResponse;
import com.example.jiajiao.utils.BaseActivity;
import com.example.jiajiao.utils.adapter.RewardAdapter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RewardActivity extends BaseActivity {
    private RecyclerView recyclerView;
    private RewardAdapter rewardAdapter;
    private List<RewardVo> rewardList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.reword_info);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.reword_layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        toolbarInit();
        contentInit();
    }

    private void contentInit() {

        recyclerView = findViewById(R.id.recycler_reword);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        RewardApi api = ApiService.getRewordApi(RewardActivity.this);
        Call<ApiResponse<List<RewardVo>>> call = api.getRewardsInfo();

        call.enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<ApiResponse<List<RewardVo>>> call, Response<ApiResponse<List<RewardVo>>> response) {
                // 检查响应是否成功
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse<List<RewardVo>> apiResponse = response.body();
                    // 获取奖学券列表
                    List<RewardVo> rewords = apiResponse.getData();

                    updateRewordList(recyclerView, rewords);
                } else {
                    Log.e("请求奖学券数据", "未知错误！请联系后台管理员");
                    Toast.makeText(RewardActivity.this, "获取失败", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<RewardVo>>> call, Throwable t) {
                Log.e("请求错误：", "网络异常");
                Toast.makeText(RewardActivity.this, "请求错误：" + "网络异常", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateRewordList(RecyclerView recyclerView, List<RewardVo> rewords) {
        if (rewords == null || rewords.isEmpty()) {
            Toast.makeText(this, "暂无奖学券数据", Toast.LENGTH_SHORT).show();
            return;
        }
        rewardList.clear();
        rewardList.addAll(rewords);

        rewardAdapter = new RewardAdapter(rewardList);
        recyclerView.setAdapter(rewardAdapter);

    }

    private void toolbarInit() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("我的奖学券");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }
}
