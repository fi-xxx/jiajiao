package com.example.jiajiao.api.apiInterface;

import com.example.jiajiao.domain.dto.EvaluateDto;

import com.example.jiajiao.domain.vo.EvaluateVo;
import com.example.jiajiao.utils.ApiResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface EvaluateApi {
    @POST("/evaluates")
    Call<ApiResponse<Boolean>> sendEvaluate(@Body EvaluateDto evaluateDto);

    @GET("/evaluates")
    Call<ApiResponse<List<EvaluateVo>>> getAllEvaluate();

    @GET("/evaluates/by-subject")
    Call<ApiResponse<List<EvaluateVo>>> getEvaluateBySubject(@Query("subject") String subject);

}
