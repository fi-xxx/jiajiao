package com.example.jiajiao.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import com.example.jiajiao.R;

import com.example.jiajiao.utils.BaseActivity;


public class MessageActivity extends BaseActivity {

    private String[] titles = {"预约老师消息", "我要提建议", "消息论坛", "优惠信息"};
    private int[] icons = {
            R.drawable.reserve,
            R.drawable.advice,
            R.drawable.remark,
            R.drawable.ticket
    };

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.message);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.message_layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        toolbarInit();

        layoutInit();

    }


    private void layoutInit() {
        LinearLayout notificationList = findViewById(R.id.notification_list);
        for (int i = 0; i < notificationList.getChildCount(); i++) {
            View item = notificationList.getChildAt(i);

            ImageView icon = item.findViewById(R.id.icon);
            TextView title = item.findViewById(R.id.title);

            title.setText(titles[i]);
            icon.setImageResource(icons[i]);

            int finalI = i;
            item.setOnClickListener(v -> {
                // 示例：点击后跳转不同页面
                Intent intent;
                switch (finalI) {
                    case 0:
                        intent = new Intent(MessageActivity.this, ReserveTeacherActivity.class);
                        break;
                    case 1:
                        intent = new Intent(MessageActivity.this, MessageEvaluateActivity.class);
                        break;
                    case 2:
                        intent = new Intent(MessageActivity.this, MessagePublicEvaluate.class);
                        break;
//                    case 3:
//                        intent = new Intent(MessageActivity.this, OtherNotificationActivity.class);
//                        break;
                    default:
                        return;
                }
                startActivity(intent);
            });
        }
    }

    private void toolbarInit() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("消息通知");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }

}
