package com.example.jiajiao.api;

import android.content.Context;

import com.example.jiajiao.api.apiInterface.EvaluateApi;
import com.example.jiajiao.api.apiInterface.ParentApi;
import com.example.jiajiao.api.apiInterface.ReserveApi;
import com.example.jiajiao.api.apiInterface.RewardApi;
import com.example.jiajiao.api.apiInterface.TeacherApi;

public class ApiService {

    public static ParentApi getParentApi(Context context) {
        return ApiClient.getRetrofit(context).create(ParentApi.class);
    }

    public static TeacherApi getTeacherApi(Context context) {
        return ApiClient.getRetrofit(context).create(TeacherApi.class);
    }

    public static ReserveApi getReserveApi(Context context) {
        return ApiClient.getRetrofit(context).create(ReserveApi.class);
    }

    public static EvaluateApi getEvaluateApi(Context context) {
        return ApiClient.getRetrofit(context).create(EvaluateApi.class);
    }

    public static RewardApi getRewordApi(Context context) {
        return ApiClient.getRetrofit(context).create(RewardApi.class);
    }



}
