package com.example.jiajiao.activities;

import static com.example.jiajiao.api.ApiService.getTeacherApi;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.jiajiao.R;
import com.example.jiajiao.activities.TeacherDetailActivity;
import com.example.jiajiao.api.apiInterface.TeacherApi;
import com.example.jiajiao.domain.vo.TeacherVo;
import com.example.jiajiao.utils.ApiResponse;
import com.example.jiajiao.utils.BaseActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchTeacherActivity extends BaseActivity {

    private Spinner spinnerSubject;
    private Spinner spinnerGrade;
    private ListView listTeacher ;
    private SimpleAdapter adapter;
    private String selectedSubject = "";
    private String selectedGrade = "";
    private boolean spinnersReady = false;
    private boolean isQuerying = false;
    private boolean isFirstInit = true; // ✅ 用来避免初始化时触发监听器
    private boolean isFirstSubjectSelection = true;
    private boolean isFirstGradeSelection = true;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.search_teacher);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.search_layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initViews();
        toolbarInit();
        initSpinners();
    }

    private void toolbarInit() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("查找教师");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void initViews() {
        spinnerSubject = findViewById(R.id.spinner_subject);
        spinnerGrade = findViewById(R.id.spinner_grade);
        listTeacher = findViewById(R.id.list_teacher);
    }

    private void initSpinners() {
        spinnerSubject.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String selected = spinnerSubject.getSelectedItem().toString();
                selectedSubject = subjectMap.get(selected);
                if (spinnersReady && !isFirstSubjectSelection) {
                    //发请求，科目应为英文
                    queryTeachers(selectedSubject, selectedGrade);
                }
                isFirstSubjectSelection = false;  // 设置为false，后续可触发
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        spinnerGrade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                selectedGrade = spinnerGrade.getSelectedItem().toString();
                if (spinnersReady && !isFirstGradeSelection) {
                    queryTeachers(selectedSubject, selectedGrade);
                }
                isFirstGradeSelection = false;
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // 延迟执行，确保 spinner 的数据已经加载完成
        spinnerSubject.postDelayed(() -> {
            spinnersReady = true;
            handleIntent();
        }, 100);
    }

    private void setSpinnerSelectionByValue(Spinner spinner, String value) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equals(value)) {
                spinner.setSelection(i);
                return;
            }
        }
        Log.w("Spinner", "未找到匹配项: " + value);
    }

    private void handleIntent() {
        String subject = getIntent().getStringExtra("subject");
        // 初始化时阻止 spinner 的触发
        isFirstSubjectSelection = true;
        isFirstGradeSelection = true;

        // 获取默认值
        selectedSubject = spinnerSubject.getSelectedItem().toString();
        selectedGrade = spinnerGrade.getSelectedItem().toString();

        // 延迟设置 spinner 选中项，确保 adapter 数据加载完成
        spinnerSubject.post(() -> {
            if (subject != null && !subject.isEmpty()) {
                setSpinnerSelectionByValue(spinnerSubject, subject);
                selectedSubject = subject;
            }

            // 再延迟触发一次查询
            spinnerGrade.post(() -> {
                isFirstSubjectSelection = false;
                isFirstGradeSelection = false;
                selectedSubject = subjectMap.get(selectedSubject);
                queryTeachers(selectedSubject, selectedGrade);
            });
        });
    }


    private void queryTeachers(String subject, String grade) {
        if (isQuerying) return;
        isQuerying = true;

        TeacherApi api = getTeacherApi(this);
        Call<ApiResponse<List<TeacherVo>>> call;
        if (grade.equals("全部") || grade.isEmpty()) {
            call = api.getBySubject(subject);
        } else {
            call = api.getBySubjectAndGrade(subject, grade);
        }

        call.enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<ApiResponse<List<TeacherVo>>> call, Response<ApiResponse<List<TeacherVo>>> response) {
                isQuerying = false;
                if (response.isSuccessful() && response.body() != null) {
                    initTeacherList(response.body().getData());
                } else {
                    Toast.makeText(SearchTeacherActivity.this, "获取失败", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<TeacherVo>>> call, Throwable t) {
                isQuerying = false;
                Log.e("请求错误：" , t.getMessage());
                Toast.makeText(SearchTeacherActivity.this, "请求错误：" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initTeacherList(List<TeacherVo> teachers) {
        List<Map<String, Object>> data = new ArrayList<>();
        for (TeacherVo teacher : teachers) {
            Map<String, Object> map = new HashMap<>();
            map.put("name", teacher.getTeacherName());
            data.add(map);
        }

        adapter = new SimpleAdapter(
                this,
                data,
                android.R.layout.simple_list_item_1,
                new String[]{"name"},
                new int[]{android.R.id.text1}
        );
        listTeacher.setAdapter(adapter);

        listTeacher.setOnItemClickListener((parent, view, position, id) -> {
            TeacherVo selectedTeacher = teachers.get(position);
            Intent intent = new Intent(this, TeacherDetailActivity.class);
            intent.putExtra("teacher", selectedTeacher);
            startActivity(intent);
        });
    }

    private final Map<String, String> subjectMap = new HashMap<>() {{
        put("数学", "Math");
        put("语文", "Chinese");
        put("英语", "English");
        put("物理", "Physics");
        put("化学", "Chemistry");
        put("生物", "Biology");
        put("地理", "Geography");
        put("政治", "Politics");
    }};
}
