package com.example.jiajiao.activities;

import static com.example.jiajiao.api.ApiService.getParentApi;
import static com.example.jiajiao.utils.Constants.BASE_URL;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.example.jiajiao.R;
import com.example.jiajiao.api.apiInterface.ParentApi;
import com.example.jiajiao.domain.dto.ParentDto;
import com.example.jiajiao.domain.vo.ParentVo;
import com.example.jiajiao.utils.ApiResponse;
import com.example.jiajiao.utils.BaseActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends BaseActivity {

    private EditText etPhone, etPassword;
    private Button btnLogin, regesterUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        // 获取视图元素
        etPhone = findViewById(R.id.login_phone);
        etPassword = findViewById(R.id.login_pwd);
        btnLogin = findViewById(R.id.login);
        regesterUser = findViewById(R.id.regester_user);

        btnLogin.setEnabled(false);
        btnLogin.setAlpha(0.5f); // 初始为灰色
        etPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String phoneInput = s.toString();
                // 如果手机号是11位数字，启用按钮；否则禁用
                btnLogin.setEnabled(phoneInput.matches("^\\d{11}$"));
                btnLogin.setAlpha(1.0f);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        // 登录按钮点击事件
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = etPhone.getText().toString();
                String password = etPassword.getText().toString();

                // 校验输入
                if (phone.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "请输入手机号和密码", Toast.LENGTH_SHORT).show();
                    return;
                }

                ParentDto parentDto = new ParentDto(phone, password);

                // 获取 API 接口实例
                ParentApi api=getParentApi(LoginActivity.this);
                // 发起登录请求
                api.login(parentDto).enqueue(new Callback<>() {
                    @Override
                    public void onResponse(Call<ApiResponse<ParentVo>> call, Response<ApiResponse<ParentVo>> response) {
                        if (response.isSuccessful()) {
                            ApiResponse<ParentVo> apiResponse = response.body();
                            if (apiResponse != null && apiResponse.getCode() == 200) {
                                ParentVo parentVo = apiResponse.getData();
                                if (parentVo != null) {
                                    // 保存 token
                                    SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
                                    prefs.edit()
                                            .putBoolean("is_logged_in", true)
                                            .putString("access_token", parentVo.getAccessToken())
                                            .putString("phone", parentVo.getPhone())
                                            .putString("refresh_token", parentVo.getRefreshToken())
                                            .apply();

                                    Toast.makeText(LoginActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
                                    Log.i("登录信息", "登录成功");
                                    // 跳转页面
                                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                            } else {
                                Toast.makeText(LoginActivity.this, apiResponse != null ? apiResponse.getMessage() : "登录失败", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(LoginActivity.this, "手机号或密码错误", Toast.LENGTH_SHORT).show();
                            Log.e("信息填写错误!", "手机号或密码错误");
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<ParentVo>> call, Throwable t) {
                        Toast.makeText(LoginActivity.this, "请求失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        Log.e("后端连接错误!", "请求失败：" + t.getMessage());

                    }
                });
            }
        });
        regesterUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}
