package com.example.jiajiao.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager2.widget.ViewPager2;

import com.example.jiajiao.R;
import com.example.jiajiao.utils.adapter.BannerAdapter;
import com.example.jiajiao.utils.BaseActivity;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends BaseActivity {

    private LinearLayout searchTeacherLinearLayout = null;
    ;
    private LinearLayout messageLinearLayout = null;

    private LinearLayout personalInfoLinearLayout = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        subjectClickJumpInit();

        searchTeacherClickJumpInit();

        messageClickJumpInit();

        personalInfoActivityJumpInit();

        imageScroll();


    }

    private void personalInfoActivityJumpInit() {
        personalInfoLinearLayout = findViewById(R.id.personal_info);
        personalInfoLinearLayout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PersonActivity.class);
            startActivity(intent);
        });
    }

    private void searchTeacherClickJumpInit() {
        searchTeacherLinearLayout = findViewById(R.id.search_teacher_layout);
        searchTeacherLinearLayout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SearchTeacherActivity.class);
            startActivity(intent);
        });
    }

    private void messageClickJumpInit() {
        messageLinearLayout = findViewById(R.id.message_layout);
        messageLinearLayout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MessageActivity.class);
            startActivity(intent);
        });
    }

    private void subjectClickJumpInit() {
        LinearLayout layoutMath = findViewById(R.id.Math);
        LinearLayout layoutEnglish = findViewById(R.id.English);
        LinearLayout layoutBiology = findViewById(R.id.Biology);
        LinearLayout layoutGeography = findViewById(R.id.Geography);
        LinearLayout layoutChinese = findViewById(R.id.Chinese);
        LinearLayout layoutPhysics = findViewById(R.id.Physics);
        LinearLayout layoutPolitics = findViewById(R.id.Politics);
        LinearLayout layoutChemistry = findViewById(R.id.Chemistry);

        layoutMath.setOnClickListener(v -> openTeacherList("数学"));
        layoutEnglish.setOnClickListener(v -> openTeacherList("英语"));
        layoutBiology.setOnClickListener(v -> openTeacherList("生物"));
        layoutGeography.setOnClickListener(v -> openTeacherList("地理"));
        layoutChinese.setOnClickListener(v -> openTeacherList("语文"));
        layoutPhysics.setOnClickListener(v -> openTeacherList("物理"));
        layoutPolitics.setOnClickListener(v -> openTeacherList("政治"));
        layoutChemistry.setOnClickListener(v -> openTeacherList("化学"));
    }

    /**
     * 设置教师图片滚动
     */
    private void imageScroll() {
        ViewPager2 viewPager = findViewById(R.id.viewPager);

        List<Integer> images = Arrays.asList(
                R.drawable.teacher1,
                R.drawable.teacher2,
                R.drawable.teacher3
        );

        BannerAdapter adapter = new BannerAdapter(images);
        viewPager.setAdapter(adapter);

        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                int next = (viewPager.getCurrentItem() + 1) % images.size();
                viewPager.setCurrentItem(next, true);
                handler.postDelayed(this, 3000);
            }
        };
        handler.postDelayed(runnable, 3000);
    }

    private void openTeacherList(String subject) {
        Intent intent = new Intent(this, SearchTeacherActivity.class);
        intent.putExtra("subject", subject);
        startActivity(intent);
    }

}