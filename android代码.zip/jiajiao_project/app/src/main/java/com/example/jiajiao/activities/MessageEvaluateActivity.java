package com.example.jiajiao.activities;

import static com.example.jiajiao.api.ApiService.getEvaluateApi;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.jiajiao.R;
import com.example.jiajiao.api.ApiService;
import com.example.jiajiao.api.apiInterface.EvaluateApi;
import com.example.jiajiao.api.apiInterface.TeacherApi;
import com.example.jiajiao.domain.dto.EvaluateDto;
import com.example.jiajiao.domain.vo.TeacherVo;
import com.example.jiajiao.utils.ApiResponse;
import com.example.jiajiao.utils.BaseActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MessageEvaluateActivity extends BaseActivity {

    private Spinner spinnerSubject, spinnerTeacher;
    private EditText editTextFeedback;
    private Button buttonSubmit;

    private TeacherApi teacherApi;
    private EvaluateApi evaluateApi;
    private List<String> teacherList = new ArrayList<>();
    private List<String> phoneList = new ArrayList<>();
    private ArrayAdapter<String> teacherAdapter;

    private String selectedSubject;
    private String selectedTeacherName;
    private String selectedTeacherPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.message_evaluate);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.message_evaluate_layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        toolbarInit();

        spinnerSubject = findViewById(R.id.spinner_subject);
        spinnerTeacher = findViewById(R.id.spinner_teacher);
        editTextFeedback = findViewById(R.id.edittext_feedback);
        buttonSubmit = findViewById(R.id.button_submit_feedback);
        teacherApi = ApiService.getTeacherApi(MessageEvaluateActivity.this);
        evaluateApi = ApiService.getEvaluateApi(MessageEvaluateActivity.this);

        initSubjectSpinner();
        setupSubmitButton();
    }


    private void toolbarInit() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("我的建议");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void initSubjectSpinner() {
        String[] subjects = getResources().getStringArray(R.array.subjects);
        ArrayAdapter<String> subjectAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, subjects);
        subjectAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSubject.setAdapter(subjectAdapter);

        spinnerSubject.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSubject = subjects[position];
                fetchTeachersBySubject(selectedSubject);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void fetchTeachersBySubject(String subject) {
        subject = subjectMap.get(subject);
        Call<ApiResponse<List<TeacherVo>>> call = teacherApi.getBySubject(subject);
        call.enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<ApiResponse<List<TeacherVo>>> call, Response<ApiResponse<List<TeacherVo>>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().getData() != null) {
                    teacherList.clear();
                    phoneList.clear();
                    for (TeacherVo teacher : response.body().getData()) {
                        teacherList.add(teacher.getTeacherName());
                        phoneList.add(teacher.getTeacherPhone());
                    }
                    ArrayAdapter<String> teacherAdapter = new ArrayAdapter<>(MessageEvaluateActivity.this,
                            android.R.layout.simple_spinner_item, teacherList);
                    teacherAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerTeacher.setAdapter(teacherAdapter);

                    spinnerTeacher.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            selectedTeacherName = teacherList.get(position);
                            selectedTeacherPhone = phoneList.get(position);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {
                        }
                    });
                } else {
                    Toast.makeText(MessageEvaluateActivity.this, "获取教师失败", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<TeacherVo>>> call, Throwable t) {
                Toast.makeText(MessageEvaluateActivity.this, "请求失败: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupSubmitButton() {
        buttonSubmit.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
            String parentPhone = prefs.getString("phone", "");
            String content = editTextFeedback.getText().toString().trim();
            if (content.isEmpty()) {
                Toast.makeText(this, "请输入建议内容", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedTeacherPhone == null) {
                Toast.makeText(this, "请选择教师", Toast.LENGTH_SHORT).show();
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            String date = sdf.format(new Date());

            EvaluateDto dto = new EvaluateDto();
            dto.setParentPhone(parentPhone);
            dto.setTeacherPhone(selectedTeacherPhone);
            dto.setSubject(selectedSubject);
            dto.setContent(content);
            dto.setDate(date);

            evaluateApi.sendEvaluate(dto).enqueue(new Callback<>() {
                @Override
                public void onResponse(Call<ApiResponse<Boolean>> call, Response<ApiResponse<Boolean>> response) {
                    if (response.isSuccessful()) {
                        Toast.makeText(MessageEvaluateActivity.this, "评价成功", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(MessageEvaluateActivity.this, "评价失败", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<ApiResponse<Boolean>> call, Throwable t) {
                    Toast.makeText(MessageEvaluateActivity.this, "请求失败: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    private final Map<String, String> subjectMap = new HashMap<>() {{
        put("数学", "Math");
        put("语文", "Chinese");
        put("英语", "English");
        put("物理", "Physics");
        put("化学", "Chemistry");
        put("生物", "Biology");
        put("地理", "Geography");
        put("政治", "Politics");
    }};


}
