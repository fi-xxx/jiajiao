package com.example.jiajiao.domain.vo;

import java.io.Serializable;

public class TeacherVo  implements Serializable {
    private Integer id;

    private String teacherPhone;
    private String teacherName;
    private String teacherSex;
    private String teacherIcon;
    private String teacherAddress;
    private String teacherExper;
    private String teacherSub;

    private String grade;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTeacherPhone() {
        return teacherPhone;
    }

    public void setTeacherPhone(String teacherPhone) {
        this.teacherPhone = teacherPhone;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getTeacherSex() {
        return teacherSex;
    }

    public void setTeacherSex(String teacherSex) {
        this.teacherSex = teacherSex;
    }

    public String getTeacherIcon() {
        return teacherIcon;
    }

    public void setTeacherIcon(String teacherIcon) {
        this.teacherIcon = teacherIcon;
    }

    public String getTeacherAddress() {
        return teacherAddress;
    }

    public void setTeacherAddress(String teacherAddress) {
        this.teacherAddress = teacherAddress;
    }

    public String getTeacherExper() {
        return teacherExper;
    }

    public void setTeacherExper(String teacherExper) {
        this.teacherExper = teacherExper;
    }

    public String getTeacherSub() {
        return teacherSub;
    }

    public void setTeacherSub(String teacherSub) {
        this.teacherSub = teacherSub;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }
}
