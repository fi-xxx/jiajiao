package com.example.jiajiao.activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jiajiao.R;
import com.example.jiajiao.api.ApiService;
import com.example.jiajiao.api.apiInterface.EvaluateApi;
import com.example.jiajiao.domain.vo.EvaluateVo;
import com.example.jiajiao.utils.ApiResponse;
import com.example.jiajiao.utils.BaseActivity;
import com.example.jiajiao.utils.adapter.EvaluateAdapter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MessagePublicEvaluate extends BaseActivity {

    private RecyclerView recyclerView;
    private Spinner subjectSpinner;
    private EvaluateAdapter adapter;
    private EvaluateApi api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.message_public_evaluate);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.message_public_evaluate_layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        toolbarInit();

        layoutInit();

        loadAllEvaluates();

    }

    private void layoutInit() {
        recyclerView = findViewById(R.id.evaluateRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EvaluateAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);
        api = ApiService.getEvaluateApi(MessagePublicEvaluate.this);

        subjectSpinner = findViewById(R.id.subjectSpinner);
        String[] subjects = {"全部", "语文", "数学", "英语", "物理", "化学"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, subjects);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subjectSpinner.setAdapter(spinnerAdapter);

        subjectSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String subject = subjects[position];
                if ("全部".equals(subject)) {
                    loadAllEvaluates();
                } else {
                    loadEvaluatesBySubject(subject);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


    }

    private void loadEvaluatesBySubject(String subject) {
        api.getEvaluateBySubject(subject).enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<ApiResponse<List<EvaluateVo>>> call, Response<ApiResponse<List<EvaluateVo>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    adapter.setData(response.body().getData());
                } else {
                    Log.e("查询教师评价信息", "无数据或加载失败");
                    Toast.makeText(MessagePublicEvaluate.this, "无数据或加载失败", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<EvaluateVo>>> call, Throwable t) {
                Log.e("查询教师评价信息", "网络错误");
                Toast.makeText(MessagePublicEvaluate.this, "网络错误", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void loadAllEvaluates() {
        api.getAllEvaluate().enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<ApiResponse<List<EvaluateVo>>> call, Response<ApiResponse<List<EvaluateVo>>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    adapter.setData(response.body().getData());
                } else {
                    Toast.makeText(MessagePublicEvaluate.this, "加载失败", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<EvaluateVo>>> call, Throwable t) {
                Toast.makeText(MessagePublicEvaluate.this, "网络错误", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void toolbarInit() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("消息论坛");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }

}
