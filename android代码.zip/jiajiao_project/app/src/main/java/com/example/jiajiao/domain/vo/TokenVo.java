package com.example.jiajiao.domain.vo;

public class TokenVo {
    String accessToken;
    String refreshToken;
    String phone;

    public TokenVo(String accessToken, String refreshToken, String phone) {
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
        this.phone = phone;
    }

    public TokenVo( String refreshToken, String phone) {
        this.refreshToken = refreshToken;
        this.phone = phone;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }


}
