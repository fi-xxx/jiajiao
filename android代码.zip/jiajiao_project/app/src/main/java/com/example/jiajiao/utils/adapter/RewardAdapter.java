package com.example.jiajiao.utils.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jiajiao.R;
import com.example.jiajiao.domain.vo.RewardVo;

import java.util.List;

public class RewardAdapter extends RecyclerView.Adapter<RewardAdapter.ViewHolder> {

    private List<RewardVo> list;
    private Context context;

    public RewardAdapter(List<RewardVo> list) {
        this.list = list;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageIcon;
        TextView textAccount, textExpire;

        public ViewHolder(View itemView) {
            super(itemView);
            imageIcon = itemView.findViewById(R.id.img_icon);
            textAccount = itemView.findViewById(R.id.tv_amount);
            textExpire = itemView.findViewById(R.id.tv_expiry);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (context == null) context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.item_reword, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        RewardVo reward = list.get(position);
        holder.textAccount.setText("¥" + reward.getAccount()+" 元");
        holder.textExpire.setText("有效期至：" + reward.getDate());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
