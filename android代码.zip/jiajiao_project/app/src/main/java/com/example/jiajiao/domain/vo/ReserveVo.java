package com.example.jiajiao.domain.vo;

public class ReserveVo {
    private String teacherName;
    private String subject;

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public ReserveVo(String teacherName, String subject) {
        this.teacherName = teacherName;
        this.subject = subject;
    }
}
