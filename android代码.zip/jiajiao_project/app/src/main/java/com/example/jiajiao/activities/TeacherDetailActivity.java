package com.example.jiajiao.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.jiajiao.R;
import com.example.jiajiao.api.ApiService;
import com.example.jiajiao.api.apiInterface.ReserveApi;
import com.example.jiajiao.domain.dto.ReserveDto;
import com.example.jiajiao.domain.vo.TeacherVo;
import com.example.jiajiao.utils.ApiResponse;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;

public class TeacherDetailActivity extends AppCompatActivity {

    private ImageView imgAvatar;
    private TextView tvName, tvSex, tvPhone, tvSubject, tvExperience;
    private Button btnBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.detail_teacher);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.detail_layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("教师预约");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // 显示返回键
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> {
            finish(); // 关闭当前页面
        });

        // 获取传来的对象
        Intent intent = getIntent();
        TeacherVo teacher = (TeacherVo) intent.getSerializableExtra("teacher");
        teacher.setTeacherSub(subjectMap.get(teacher.getTeacherSub()));
        String experience = teacher.getTeacherExper();
        teacher.setTeacherExper(experience == null ? "无" : experience);
        // 绑定布局组件
        imgAvatar = findViewById(R.id.img_teacher_avatar);
        tvName = findViewById(R.id.tv_teacher_name);
        tvSex = findViewById(R.id.tv_teacher_sex);
        tvPhone = findViewById(R.id.tv_teacher_phone);
        tvSubject = findViewById(R.id.tv_teacher_subject);
        tvExperience = findViewById(R.id.tv_teacher_experience);
        btnBook = findViewById(R.id.btn_book);

        // 设置教师信息
        if (teacher != null) {
            tvName.setText(teacher.getTeacherName());
            tvSex.setText("性别：" + teacher.getTeacherSex());
            tvPhone.setText("电话：" + teacher.getTeacherPhone());
            tvSubject.setText("科目：" + teacher.getTeacherSub());
            tvExperience.setText("教学经历：" + teacher.getTeacherExper());

            // 头像默认使用静态图 person.png
        }

        // 点击预约按钮
        btnBook.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

            ReserveDto reserveDto = new ReserveDto();
            reserveDto.setTeacherPhone(teacher.getTeacherPhone());
            reserveDto.setParentPhone(prefs.getString("phone", ""));
            reserveDto.setTeacherName(teacher.getTeacherName());
            reserveDto.setSubject(teacher.getTeacherSub());

            reserveDto.setDate(sdf.format(new Date())); // 当前时间

            ReserveApi api = ApiService.getReserveApi(TeacherDetailActivity.this);
            Call<ApiResponse<Boolean>> call = api.bookTeacher(reserveDto);
            call.enqueue(new retrofit2.Callback<>() {
                @Override
                public void onResponse(Call<ApiResponse<Boolean>> call, retrofit2.Response<ApiResponse<Boolean>> response) {
                    if (response.isSuccessful() && response.body() != null && response.body().getData()) {
                        Log.d("教师预约", "预约成功");
                        Toast.makeText(TeacherDetailActivity.this, "预约成功", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.e("教师预约", "预约失败");
                        Toast.makeText(TeacherDetailActivity.this, "预约失败，请重试", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<ApiResponse<Boolean>> call, Throwable t) {
                    Log.e("教师预约", "网络错误！");
                    Toast.makeText(TeacherDetailActivity.this, "网络错误：" + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
            Toast.makeText(this, "预约成功", Toast.LENGTH_SHORT).show();
        });
    }

    //很愚蠢的方法，只是为了显示，但是  有效。
    private final Map<String, String> subjectMap = new HashMap<>() {{
        put("math", "数学");
        put("chinese", "语文");
        put("english", "英语");
        put("physics", "物理");
        put("chemistry", "化学");
        put("biology", "生物");
        put("geography", "地理");
        put("politics", "政治");
    }};
}
