package com.example.jiajiao.domain.dto;




public class EvaluateDto {
    private String parentPhone;
    private String teacherPhone;
    private String content;
    private String date;
    private String subject;

    public EvaluateDto(String parentPhone, String teacherPhone, String content, String data, String subject) {
        this.parentPhone = parentPhone;
        this.teacherPhone = teacherPhone;
        this.content = content;
        this.date = data;
        this.subject = subject;
    }

    public EvaluateDto() {
        return;
    }


    public String getParentPhone() {
        return parentPhone;
    }

    public void setParentPhone(String parentPhone) {
        this.parentPhone = parentPhone;
    }

    public String getTeacherPhone() {
        return teacherPhone;
    }

    public void setTeacherPhone(String teacherPhone) {
        this.teacherPhone = teacherPhone;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
