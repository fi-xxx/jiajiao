package com.example.jiajiao.domain.dto;

import java.util.Date;


public class ReserveDto {
    private String parentPhone;
    private String teacherPhone;
    private String teacherName;
    private String subject;
    private String date;

    public String getParentPhone() {
        return parentPhone;
    }

    public void setParentPhone(String parentPhone) {
        this.parentPhone = parentPhone;
    }

    public String getTeacherPhone() {
        return teacherPhone;
    }

    public void setTeacherPhone(String teacherPhone) {
        this.teacherPhone = teacherPhone;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String   getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
