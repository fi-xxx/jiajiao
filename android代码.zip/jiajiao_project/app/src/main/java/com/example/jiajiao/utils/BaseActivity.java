package com.example.jiajiao.utils;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.jiajiao.activities.LoginActivity;
import com.example.jiajiao.activities.RegisterActivity;

public class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!isLoggedIn()) {
            // 用户未登录，跳转到登录页面
            if (!(this instanceof LoginActivity) && !(this instanceof RegisterActivity)) {
                Toast.makeText(this, "请先登录", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // 清除任务栈
                startActivity(intent);
            }
        }
    }

    protected boolean isLoggedIn() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        boolean isLoggedIn = prefs.getBoolean("is_logged_in", false);
        String accessToken = prefs.getString("access_token",null);
        return (isLoggedIn&&accessToken!=null);
    }
}
