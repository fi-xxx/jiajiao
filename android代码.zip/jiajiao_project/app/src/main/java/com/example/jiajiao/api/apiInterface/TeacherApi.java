package com.example.jiajiao.api.apiInterface;

import com.example.jiajiao.domain.vo.TeacherVo;
import com.example.jiajiao.utils.ApiResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface TeacherApi {

    @GET("/teachers/by-subject")
    Call<ApiResponse<List<TeacherVo>>> getBySubject(@Query("subject")String subject);
    @GET("/teachers/by-subject-grade")
    Call<ApiResponse<List<TeacherVo>>> getBySubjectAndGrade(
            @Query("subject")String subject,
            @Query("grade")String grade);

}
