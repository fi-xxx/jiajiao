package com.example.jiajiao.api.apiInterface;

import com.example.jiajiao.domain.vo.RewardVo;
import com.example.jiajiao.utils.ApiResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface RewardApi {
    @GET("/rewords")
    Call<ApiResponse<List<RewardVo>>> getRewardsInfo();
}
