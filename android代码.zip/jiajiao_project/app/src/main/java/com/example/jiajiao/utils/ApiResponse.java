package com.example.jiajiao.utils;

public class ApiResponse<T> {
    private int code;      // 状态码
    private String message; // 返回的消息
    private T data;        // 实际的数据

    // Getters 和 Setters
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
